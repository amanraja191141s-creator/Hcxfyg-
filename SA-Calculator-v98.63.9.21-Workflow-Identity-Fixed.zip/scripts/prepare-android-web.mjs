import { cp, mkdir, rm, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'www');
const required = [
  'index.html', 'assets/css/app.css', 'assets/js/app.js',
  'assets/js/localization.js', 'assets/js/currency-localized-names.js',
  'assets/js/theme-bootstrap.js', 'assets/brand/sa-calculator-icon.png',
  'assets/brand/sa-calculator-192.png', 'assets/brand/sa-calculator-512.png',
  'assets/brand/sa-calculator-home-logo.svg', 'assets/brand/sa-home-neon-wave.svg',
  'manifest.webmanifest', 'service-worker.js'
];
for (const item of required) {
  try { await access(path.join(root, item)); }
  catch { throw new Error(`Required app asset is missing: ${item}`); }
}
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const item of ['index.html', 'manifest.webmanifest', 'service-worker.js', 'assets']) {
  await cp(path.join(root, item), path.join(out, item), { recursive: true });
}
const productionCss = path.join(out, 'assets/css/app.css');
await access(productionCss);
console.log(`Android web bundle prepared: ${required.length} required assets verified; one canonical stylesheet copied (no legacy CSS rebuild layers).`);
