import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');

test('Tools catalogue follows grouped three-column reference layout without losing tool actions', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const start = html.indexOf('id="premium-tools-grid"');
  const end = html.indexOf('id="tools-empty-state"', start);
  const grid = html.slice(start, end);
  const ids = [...grid.matchAll(/data-tool-screen="([a-z]+)"/g)].map(m => m[1]);
  assert.equal(ids.length, 16);
  assert.equal(new Set(ids).size, 16);
  for (const heading of ['Finance &amp; Money','Math &amp; General Utilities','Health','Daily Utilities']) {
    assert.ok(grid.includes(heading) || grid.includes(heading.replaceAll('&amp;','&')));
  }
  assert.match(html, /id="tools-inline-search"/);
  assert.match(html, /id="tools-back-to-calculator"/);
  assert.match(js, /tools-back-to-calculator.*switchScreen\('calc'\)/s);
  assert.match(read('assets/css/app.css'), /grid-template-columns:repeat\(3,minmax\(0,1fr\)\)!important/);
});

test('Unit Converter opens a category tile chooser, then the existing converter engine', () => {
  const html = read('index.html');
  const js = read('assets/js/app.js');
  const css = read('assets/css/app.css');
  const keys = [...html.matchAll(/data-unit-category="([a-z]+)"/g)].map(m => m[1]);
  assert.equal(keys.length, 12);
  assert.equal(new Set(keys).size, 12);
  assert.match(html, /id="unit-category-picker"/);
  assert.match(html, /id="unit-converter-workspace" hidden/);
  assert.match(html, /id="unit-category-back"/);
  assert.match(js, /showUnitConverter/);
  assert.match(js, /showUnitCategoryPicker/);
  assert.match(js, /updateUnitSelects\(\)/);
  assert.match(css, /#screen-units\.active \.unit-category-picker/);
});

test('release metadata and Android workflow use v98.63.9.21 consistently', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const workflow = read('.github/workflows/main.yml');
  assert.equal(pkg.version, '1.98.69-v98.63.9.21');
  assert.equal(manifest.version, '1.98.69-v98.63.9.21');
  assert.match(workflow, /v98\.63\.9\.21/);
  assert.match(workflow, /1098069/);
});
