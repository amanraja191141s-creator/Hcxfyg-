'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../server.js');

let server;
let baseUrl;

test.before(async () => {
  server = createServer();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
  if (server?.listening) await new Promise(resolve => server.close(resolve));
});

test('static server serves the app with hardened response headers', async () => {
  const response = await fetch(`${baseUrl}/`);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type') || '', /text\/html/);
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(response.headers.get('x-frame-options'), 'DENY');
  assert.match(await response.text(), /SA Calculator/);
});

test('HEAD returns the matching representation length without a response body', async () => {
  const get = await fetch(`${baseUrl}/assets/css/app.css`);
  const bytes = (await get.arrayBuffer()).byteLength;
  const head = await fetch(`${baseUrl}/assets/css/app.css`, { method: 'HEAD' });
  assert.equal(head.status, 200);
  assert.equal(Number(head.headers.get('content-length')), bytes);
  assert.equal((await head.arrayBuffer()).byteLength, 0);
});

test('encoded NUL paths return 400 without terminating the server', async () => {
  const response = await fetch(`${baseUrl}/%00`);
  assert.equal(response.status, 400);
  const followUp = await fetch(`${baseUrl}/`);
  assert.equal(followUp.status, 200);
});

test('encoded traversal and hidden files are not exposed', async () => {
  const traversal = await fetch(`${baseUrl}/%2e%2e%2fpackage.json`);
  assert.equal(traversal.status, 403);
  const hidden = await fetch(`${baseUrl}/.gitignore`);
  assert.equal(hidden.status, 404);
});

test('unsupported methods are rejected with an Allow header', async () => {
  const response = await fetch(`${baseUrl}/`, { method: 'POST' });
  assert.equal(response.status, 405);
  assert.equal(response.headers.get('allow'), 'GET, HEAD');
});


test('symlinks cannot expose files outside the application root', async () => {
  const outsideDir = fs.mkdtempSync(path.join(os.tmpdir(), 'sa-calculator-outside-'));
  const outsideFile = path.join(outsideDir, 'private.txt');
  const linkPath = path.join(__dirname, 'server-outside-link.txt');
  try {
    fs.writeFileSync(outsideFile, 'private sentinel');
    fs.symlinkSync(outsideFile, linkPath);
    const response = await fetch(`${baseUrl}/tests/server-outside-link.txt`);
    assert.equal(response.status, 403);
    assert.doesNotMatch(await response.text(), /private sentinel/);
  } finally {
    try { fs.unlinkSync(linkPath); } catch (_) {}
    fs.rmSync(outsideDir, { recursive: true, force: true });
  }
});
