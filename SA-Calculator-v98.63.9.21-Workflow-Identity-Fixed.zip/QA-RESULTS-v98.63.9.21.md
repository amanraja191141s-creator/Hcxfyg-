# QA results — v98.63.9.21

- Release automated tests: **38/38 passed, 0 failed**.
- JavaScript syntax check: PASS.
- Android web bundle: PASS — 13 required assets verified.
- Generated bundle includes new grouped Tools catalogue and Unit category picker: PASS.
- GitHub Actions YAML parse: PASS.
- ZIP integrity: checked after packaging.
- Android workflow versionCode: `1098069`.
- PWA cache identity: `v9863921-video-overlay`.

## Not device-certified
Fresh APK installation, Android WebView visual comparison, real finger gestures, scroll inertia and OEM navigation gesture conflicts must be checked on the target phone.
