from pathlib import Path
import re
root=Path('/mnt/data/audit919')
# Rebuild the 4x4 scientific matrix to match the supplied recording.
p=root/'index.html'; s=p.read_text()
pattern=r'<div class="scientific-function-grid" aria-label="Scientific functions">[\s\S]*?</div>'
new='''<div class="scientific-function-grid" aria-label="Scientific functions">
          <button type="button" id="sci-shift-toggle" aria-pressed="false" aria-label="Inverse functions">INV</button>
          <button type="button" data-sci-insert="sin(" data-sci-alt-insert="asin(" data-sci-label="sin" data-sci-alt-label="sin⁻¹" data-sci-hint="SHIFT: sin⁻¹">sin</button>
          <button type="button" data-sci-insert="cos(" data-sci-alt-insert="acos(" data-sci-label="cos" data-sci-alt-label="cos⁻¹" data-sci-hint="SHIFT: cos⁻¹">cos</button>
          <button type="button" data-sci-insert="tan(" data-sci-alt-insert="atan(" data-sci-label="tan" data-sci-alt-label="tan⁻¹" data-sci-hint="SHIFT: tan⁻¹">tan</button>
          <button type="button" data-sci-insert="ln(" data-sci-alt-insert="2.718281828459045^(" data-sci-label="ln" data-sci-alt-label="eˣ" data-sci-hint="SHIFT: eˣ">ln</button>
          <button type="button" data-sci-insert="log(" data-sci-alt-insert="log2(" data-sci-label="log" data-sci-alt-label="log₂" data-sci-hint="SHIFT: log₂">log</button>
          <button type="button" data-sci-insert="abs(" data-sci-hint="ABS">|x|</button>
          <button type="button" data-sci-insert="fact(" data-sci-hint="FACTORIAL">x!</button>
          <button type="button" data-sci-insert="pi" data-sci-hint="CONSTANT">π</button>
          <button type="button" data-sci-insert="2.718281828459045" data-sci-hint="CONSTANT">e</button>
          <button type="button" data-sci-insert="2.718281828459045^(" data-sci-hint="EXPONENTIAL">eˣ</button>
          <button type="button" data-sci-insert="sqrt(" data-sci-hint="SQUARE ROOT">√</button>
          <button type="button" data-sci-insert="10^(" data-sci-hint="POWER OF TEN">10ˣ</button>
          <button type="button" data-sci-insert="^2" data-sci-hint="SQUARE">x²</button>
          <button type="button" data-sci-insert="^" data-sci-hint="POWER">xʸ</button>
          <button type="button" id="sci-more-toggle" aria-expanded="false" aria-controls="sci-more-functions" aria-label="More scientific functions">＋</button>
        </div>'''
s2,n=re.subn(pattern,new,s,count=1)
assert n==1, 'scientific grid not found'
s=s2
# Make extended functions available from More, not in the reference 4x4 matrix.
s=s.replace('<div class="scientific-more-functions" id="sci-more-functions" hidden aria-label="Additional scientific functions"><button type="button" data-sci-insert="asin(">sin⁻¹</button><button type="button" data-sci-insert="acos(">cos⁻¹</button><button type="button" data-sci-insert="atan(">tan⁻¹</button><button type="button" data-sci-insert="log2(">log₂</button><button type="button" data-sci-insert="cbrt(">∛x</button><button type="button" data-sci-action="ans">ANS</button></div>', '<div class="scientific-more-functions" id="sci-more-functions" hidden aria-label="Additional scientific functions"><button type="button" data-sci-insert="asin(">sin⁻¹</button><button type="button" data-sci-insert="acos(">cos⁻¹</button><button type="button" data-sci-insert="atan(">tan⁻¹</button><button type="button" data-sci-insert="log2(">log₂</button><button type="button" data-sci-insert="cbrt(">∛x</button><button type="button" data-sci-insert="1/(">x⁻¹</button><button type="button" data-sci-action="ans">ANS</button></div>')
p.write_text(s)

# Replace old split-screen class and end-of-init gesture code.
p=root/'assets/js/app.js'; js=p.read_text()
start=js.index('  // Scientific functions are an edge-swipe drawer attached to the standard')
end=js.index('\n}\n\nconst CURRENCY_CATALOG', start)
block=r'''  // Video-matched scientific keypad: a right-edge drawer overlays the normal
  // keypad only. The main display and standard keypad keep their original geometry.
  const calcScreen = document.getElementById('screen-calc');
  const mainKeypad = calcScreen?.querySelector('.main-keypad');
  const functionGrid = screen.querySelector('.scientific-function-grid');
  const closeButton = document.getElementById('sci-drawer-close');
  const shiftButton = document.getElementById('sci-shift-toggle');
  const angleButton = document.getElementById('sci-angle-toggle');
  const displayTopline = screen.querySelector('.scientific-display-topline');
  if (functionGrid && shiftButton && shiftButton.parentElement !== functionGrid) functionGrid.prepend(shiftButton);
  if (displayTopline && angleButton && angleButton.parentElement !== displayTopline) displayTopline.insertBefore(angleButton, displayTopline.querySelector('.scientific-display-spacer'));
  const syncDrawerGeometry = () => {
    if (!calcScreen || !mainKeypad) return;
    const calcRect = calcScreen.getBoundingClientRect();
    const keypadRect = mainKeypad.getBoundingClientRect();
    screen.style.top = `${Math.max(0, keypadRect.top - calcRect.top)}px`;
    screen.style.height = `${Math.max(120, keypadRect.height)}px`;
  };
  let drawerOpen = false;
  let gestureStart = null;
  let suppressDrawerClickUntil = 0;
  const panelWidth = () => Math.max(1, screen.getBoundingClientRect().width || (window.innerWidth * .9));
  const setDrawerOffset = offset => screen.style.setProperty('--sci-drawer-x', `${Math.max(0, offset)}px`);
  const setOpenState = open => {
    drawerOpen = open;
    screen.classList.toggle('is-open', open);
    screen.classList.toggle('active', open);
    calcScreen?.classList.toggle('scientific-overlay-open', open);
    screen.setAttribute('aria-hidden', String(!open));
    screen.inert = !open;
    document.body.classList.toggle('scientific-drawer-open', open);
    if (open) {
      syncDrawerGeometry();
      screen.style.removeProperty('--sci-drawer-x');
    } else {
      screen.style.removeProperty('--sci-drawer-x');
      const more = document.getElementById('sci-more-functions');
      const moreToggle = document.getElementById('sci-more-toggle');
      if (more) more.hidden = true;
      if (moreToggle) moreToggle.setAttribute('aria-expanded', 'false');
    }
  };
  const openDrawer = () => {
    if (drawerOpen) return;
    syncDrawerGeometry();
    setOpenState(true);
  };
  const closeDrawer = (restoreFocus = false) => {
    if (!drawerOpen) return;
    setOpenState(false);
    if (restoreFocus) document.getElementById('calc-expr')?.focus({ preventScroll: true });
  };
  closeButton?.addEventListener('click', () => closeDrawer(true));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && drawerOpen) { event.preventDefault(); closeDrawer(true); }
  });
  const gestureDown = event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (event.isPrimary === false) return;
    const x = event.clientX, y = event.clientY;
    const width = window.innerWidth || document.documentElement.clientWidth;
    const keypadRect = mainKeypad?.getBoundingClientRect();
    const panelRect = screen.getBoundingClientRect();
    const onKeypadBand = !!keypadRect && y >= keypadRect.top && y <= keypadRect.bottom;
    const fromRightEdge = !drawerOpen && onKeypadBand && x >= width - 36;
    const fromPanel = drawerOpen && x >= panelRect.left && y >= panelRect.top && y <= panelRect.bottom;
    if (!fromRightEdge && !fromPanel) { gestureStart = null; return; }
    const w = panelWidth();
    gestureStart = { x, y, open: drawerOpen, pointerId: event.pointerId, width: w, lastX: x, lastT: performance.now(), velocity: 0 };
    screen.classList.add('is-dragging');
    screen.style.visibility = 'visible';
    screen.style.pointerEvents = 'auto';
    setDrawerOffset(drawerOpen ? 0 : w);
  };
  const gestureMove = event => {
    const start = gestureStart;
    if (!start || (start.pointerId !== undefined && event.pointerId !== start.pointerId)) return;
    const dx = event.clientX - start.x;
    const dy = event.clientY - start.y;
    if (Math.abs(dy) > Math.abs(dx) * 1.15 && Math.abs(dy) > 12) {
      gestureStart = null; screen.classList.remove('is-dragging'); screen.style.removeProperty('--sci-drawer-x'); return;
    }
    const now = performance.now();
    const dt = Math.max(1, now - start.lastT);
    start.velocity = (event.clientX - start.lastX) / dt;
    start.lastX = event.clientX; start.lastT = now;
    const offset = start.open ? Math.max(0, Math.min(start.width, dx)) : Math.max(0, Math.min(start.width, start.width + dx));
    setDrawerOffset(offset);
    if (Math.abs(dx) > 10) start.moved = true;
  };
  const gestureUp = event => {
    const start = gestureStart;
    if (!start) return;
    gestureStart = null;
    if (start.pointerId !== undefined && event.pointerId !== start.pointerId) { screen.classList.remove('is-dragging'); screen.style.removeProperty('--sci-drawer-x'); return; }
    const dx = event.clientX - start.x;
    const dy = event.clientY - start.y;
    const offset = start.open ? Math.max(0, Math.min(start.width, dx)) : Math.max(0, Math.min(start.width, start.width + dx));
    const progress = 1 - offset / start.width;
    const horizontal = Math.abs(dx) >= 34 && Math.abs(dx) > Math.abs(dy) * 1.2;
    const flickOpen = !start.open && start.velocity < -0.48;
    const flickClose = start.open && start.velocity > 0.48;
    const shouldOpen = start.open ? !(progress < 0.58 || flickClose) : (progress > 0.42 || flickOpen);
    screen.classList.remove('is-dragging');
    if (horizontal && start.moved) suppressDrawerClickUntil = Date.now() + 420;
    setOpenState(horizontal ? shouldOpen : start.open);
  };
  calcScreen?.addEventListener('pointerdown', gestureDown, { passive: true, capture: true });
  document.addEventListener('pointermove', gestureMove, { passive: true });
  document.addEventListener('pointerup', gestureUp, { passive: true });
  document.addEventListener('pointercancel', () => {
    if (!gestureStart) return;
    const wasOpen = gestureStart.open; gestureStart = null; screen.classList.remove('is-dragging'); setOpenState(wasOpen);
  }, { passive: true });
  screen.addEventListener('click', event => {
    if (Date.now() < suppressDrawerClickUntil) { event.preventDefault(); event.stopImmediatePropagation(); }
  }, true);
  const resizeObserver = typeof ResizeObserver !== 'undefined' && mainKeypad ? new ResizeObserver(() => { if (drawerOpen) syncDrawerGeometry(); }) : null;
  resizeObserver?.observe(mainKeypad);
  window.addEventListener('resize', () => { if (drawerOpen) syncDrawerGeometry(); }, { passive: true });
  // Keep the drawer closed and non-interactive until an intentional edge swipe.
  screen.classList.remove('active', 'is-open', 'is-dragging');
  screen.setAttribute('aria-hidden', 'true');
  screen.inert = true;
  screen.setAttribute('role', 'complementary');
  if (angleButton) { angleButton.textContent = sci.angle.toUpperCase(); angleButton.setAttribute('aria-label', `Angle mode ${sci.angle.toUpperCase()}; toggle degrees or radians`); }
'''
js=js[:start]+block+js[end:]
# Update angle button label whenever angle changes.
old="const setAngle = angle => { sci.angle = angle === 'rad' ? 'rad' : 'deg'; STATE.calcAngleMode = sci.angle; try { localStorage.setItem('sa_scientific_angle_v1', sci.angle); } catch {} const angleIndicator = document.getElementById('sci-angle-indicator'); if (angleIndicator) angleIndicator.textContent = sci.angle.toUpperCase(); render(); updateCalcDisplayDOM(false); };"
newset="const setAngle = angle => { sci.angle = angle === 'rad' ? 'rad' : 'deg'; STATE.calcAngleMode = sci.angle; try { localStorage.setItem('sa_scientific_angle_v1', sci.angle); } catch {} const angleIndicator = document.getElementById('sci-angle-indicator'); if (angleIndicator) angleIndicator.textContent = sci.angle.toUpperCase(); const angleButton = document.getElementById('sci-angle-toggle'); if (angleButton) { angleButton.textContent = sci.angle.toUpperCase(); angleButton.setAttribute('aria-label', `Angle mode ${sci.angle.toUpperCase()}; toggle degrees or radians`); } render(); updateCalcDisplayDOM(false); };"
assert old in js
js=js.replace(old,newset)
p.write_text(js)

# Append final authoritative overlay CSS; it supersedes all historical split rules.
p=root/'assets/css/app.css'; css=p.read_text()
css += r'''

/* v98.63.9.20 — match the supplied video: scientific functions slide over the
   keypad from the right; the normal keypad never resizes and the display stays full-width. */
#screen-calc { position:relative!important; overflow:hidden!important; isolation:isolate!important; }
#screen-calc > .main-keypad { width:100%!important; max-width:100%!important; transform:none!important; transition:none!important; }
#screen-calc.scientific-overlay-open > .main-keypad { width:100%!important; max-width:100%!important; flex-basis:var(--main-keypad-basis,64%)!important; }
#screen-calc #screen-scientific.scientific-drawer {
  display:flex!important; position:absolute!important; z-index:80!important;
  top:var(--sci-drawer-top,38%)!important; right:0!important; bottom:auto!important; left:auto!important;
  width:min(90%,680px)!important; max-width:90%!important; height:var(--sci-drawer-height,58%)!important;
  min-height:0!important; max-height:none!important; box-sizing:border-box!important;
  margin:0!important; padding:8px 9px max(8px,env(safe-area-inset-bottom))!important;
  overflow:hidden!important; visibility:hidden!important; pointer-events:none!important;
  transform:translate3d(101%,0,0)!important; opacity:1!important;
  background:var(--surface-1,#0b2038)!important;
  border:1px solid var(--ui-border,rgba(110,170,220,.38))!important;
  border-right:0!important; border-radius:18px 0 0 18px!important;
  box-shadow:-16px 0 34px rgba(0,0,0,.34)!important;
  transition:transform 260ms cubic-bezier(.22,.78,.22,1),visibility 260ms!important;
  will-change:transform; touch-action:pan-y!important;
}
#screen-calc #screen-scientific.scientific-drawer.is-open {
  visibility:visible!important; pointer-events:auto!important; transform:translate3d(0,0,0)!important;
}
#screen-calc #screen-scientific.scientific-drawer.is-dragging {
  visibility:visible!important; pointer-events:auto!important;
  transform:translate3d(var(--sci-drawer-x,101%),0,0)!important; transition:none!important;
}
#screen-calc #screen-scientific .scientific-workspace {
  display:flex!important; flex:1 1 auto!important; flex-direction:column!important;
  width:100%!important; min-width:0!important; min-height:0!important; gap:7px!important; overflow:hidden!important;
}
#screen-calc #screen-scientific .scientific-display {
  display:flex!important; flex:0 0 34px!important; min-height:34px!important; max-height:34px!important;
  margin:0!important; padding:0 2px!important; border:0!important; border-radius:0!important;
  box-shadow:none!important; background:transparent!important; overflow:hidden!important;
}
#screen-calc #screen-scientific .scientific-display-topline {
  display:flex!important; flex:1 1 auto!important; min-height:34px!important; align-items:center!important;
  justify-content:space-between!important; gap:8px!important; font-size:13px!important;
}
#screen-calc #screen-scientific #sci-angle-indicator { display:none!important; }
#screen-calc #screen-scientific #sci-memory-indicator,
#screen-calc #screen-scientific #sci-history-toggle,
#screen-calc #screen-scientific .scientific-expression,
#screen-calc #screen-scientific .scientific-result,
#screen-calc #screen-scientific .scientific-display-footer,
#screen-calc #screen-scientific .scientific-memory-row,
#screen-calc #screen-scientific .scientific-keypad,
#screen-calc #screen-scientific .scientific-history-panel { display:none!important; }
#screen-calc #screen-scientific .scientific-display-spacer { flex:1 1 auto!important; }
#screen-calc #screen-scientific #sci-angle-toggle {
  display:inline-flex!important; flex:0 0 auto!important; min-width:82px!important; width:auto!important;
  min-height:30px!important; height:30px!important; padding:0 12px!important; border-radius:9px!important;
  align-items:center!important; justify-content:center!important; font-size:12px!important; font-weight:700!important;
  color:var(--text-primary,#f1f7ff)!important; background:var(--surface-2,#102b47)!important;
  border:1px solid var(--ui-border,rgba(95,157,205,.28))!important;
}
#screen-calc #screen-scientific .sci-drawer-close {
  display:inline-flex!important; flex:0 0 32px!important; width:32px!important; min-width:32px!important;
  height:32px!important; min-height:32px!important; padding:0!important; border-radius:9px!important;
  align-items:center!important; justify-content:center!important; font-size:22px!important;
  color:var(--text-primary,#f1f7ff)!important; background:var(--surface-2,#102b47)!important;
  border:1px solid var(--ui-border,rgba(95,157,205,.28))!important;
}
#screen-calc #screen-scientific .scientific-toolbar { display:none!important; }
#screen-calc #screen-scientific .scientific-function-grid {
  display:grid!important; flex:1 1 auto!important; min-height:0!important; width:100%!important;
  grid-template-columns:repeat(4,minmax(0,1fr))!important;
  grid-template-rows:repeat(4,minmax(0,1fr))!important; grid-auto-flow:row!important;
  gap:clamp(5px,1.2vw,10px)!important; overflow:hidden!important; overscroll-behavior:contain!important;
}
#screen-calc #screen-scientific .scientific-function-grid > button {
  display:flex!important; position:relative!important; min-width:0!important; min-height:0!important;
  width:100%!important; height:100%!important; max-height:none!important; padding:4px!important;
  align-items:center!important; justify-content:center!important; border-radius:12px!important;
  border:1px solid var(--ui-border,rgba(95,157,205,.25))!important;
  background:var(--surface-2,#102b47)!important; color:var(--text-primary,#f1f7ff)!important;
  font-size:clamp(15px,4.1vw,25px)!important; font-weight:600!important; line-height:1!important;
  white-space:nowrap!important; touch-action:manipulation!important; -webkit-tap-highlight-color:transparent!important;
}
#screen-calc #screen-scientific .scientific-function-grid > #sci-shift-toggle,
#screen-calc #screen-scientific .scientific-function-grid > button[data-sci-insert="sin("],
#screen-calc #screen-scientific .scientific-function-grid > button[data-sci-insert="cos("],
#screen-calc #screen-scientific .scientific-function-grid > button[data-sci-insert="tan("] { color:var(--accent-cyan,#45cfff)!important; }
#screen-calc #screen-scientific #sci-shift-toggle[aria-pressed="true"] { background:var(--accent,#168bff)!important; color:#fff!important; }
#screen-calc #screen-scientific #sci-more-toggle {
  position:absolute!important; right:13px!important; bottom:13px!important; z-index:3!important;
  width:58px!important; height:58px!important; min-width:58px!important; min-height:58px!important;
  border-radius:50%!important; border:0!important; background:var(--accent,#168bff)!important;
  color:#fff!important; box-shadow:0 5px 15px rgba(0,0,0,.32)!important; font-size:34px!important;
}
#screen-calc #screen-scientific .scientific-more-functions:not([hidden]) {
  display:grid!important; position:absolute!important; z-index:4!important; inset:42px 8px 8px!important;
  grid-template-columns:repeat(3,minmax(0,1fr))!important; grid-auto-rows:minmax(48px,1fr)!important;
  gap:8px!important; padding:12px!important; overflow:auto!important; border-radius:14px!important;
  background:var(--surface-1,#0b2038)!important; border:1px solid var(--ui-border,rgba(95,157,205,.3))!important;
}
#screen-calc #screen-scientific .scientific-more-functions button {
  min-width:0!important; min-height:44px!important; border-radius:10px!important;
  background:var(--surface-2,#102b47)!important; color:var(--text-primary,#f1f7ff)!important;
  border:1px solid var(--ui-border,rgba(95,157,205,.25))!important; font-size:15px!important;
}
#screen-calc::after {
  content:""!important; position:absolute!important; z-index:79!important; top:var(--sci-drawer-top,38%)!important;
  right:0!important; bottom:auto!important; width:5px!important; height:var(--sci-drawer-height,58%)!important;
  max-height:100%!important; border-radius:5px 0 0 5px!important; background:var(--accent,#168bff)!important;
  opacity:.38!important; pointer-events:none!important; transition:opacity .2s ease!important;
}
#screen-calc.scientific-overlay-open::after { opacity:0!important; }
#screen-calc.scientific-overlay-open > .main-keypad { touch-action:pan-y!important; }
@media(max-width:380px) {
  #screen-calc #screen-scientific.scientific-drawer { width:92%!important; max-width:92%!important; padding:6px!important; }
  #screen-calc #screen-scientific .scientific-function-grid { gap:4px!important; }
  #screen-calc #screen-scientific .scientific-function-grid > button { border-radius:9px!important; font-size:clamp(14px,4vw,19px)!important; }
}
@media(max-height:620px) {
  #screen-calc #screen-scientific .scientific-display { flex-basis:28px!important; min-height:28px!important; max-height:28px!important; }
  #screen-calc #screen-scientific .scientific-workspace { gap:4px!important; }
  #screen-calc #screen-scientific #sci-more-toggle { width:46px!important; height:46px!important; min-width:46px!important; min-height:46px!important; }
}
@media(prefers-reduced-motion:reduce) {
  #screen-calc #screen-scientific.scientific-drawer { transition:none!important; }
}
'''
p.write_text(css)

# Version and cache/workflow synchronization.
replacements={
 '1.98.67-v98.63.9.19':'1.98.68-v98.63.9.20',
 'v98.63.9.19':'v98.63.9.20',
 'v9863919-sci-split':'v9863920-video-overlay',
 '1098067':'1098068',
}
for rel in ['package.json','index.html','service-worker.js','.github/workflows/main.yml','manifest.webmanifest','capacitor.config.json','README.md']:
 q=root/rel
 if q.exists():
  t=q.read_text(errors='ignore')
  for a,b in replacements.items(): t=t.replace(a,b)
  q.write_text(t)
# Update npm release test command.
q=root/'package.json'; t=q.read_text(); t=t.replace('scientific-edge-drawer-v9863919.test.mjs','scientific-edge-drawer-v9863920.test.mjs'); q.write_text(t)
# Workflow test references/version identity.
q=root/'.github/workflows/main.yml'; t=q.read_text().replace('tests/scientific-edge-drawer-v9863919.test.mjs','tests/scientific-edge-drawer-v9863920.test.mjs').replace('v9863919-sci-split','v9863920-video-overlay'); q.write_text(t)
