# QA results — v98.63.9.21 workflow identity hotfix

## Root cause
The source archive package.json declares `1.98.69-v98.63.9.21`, but the workflow source selector and APK versionName assertion expected `1.98.68-v98.63.9.21`. The README also documented the stale `.68` version and versionCode `1098068`. The archive itself passed ZIP integrity validation.

## Corrections
- Source selector `SA_EXPECTED_VERSION`: `1.98.69-v98.63.9.21`.
- APK `versionName` assertion: `1.98.69-v98.63.9.21`.
- APK `versionCode` assertion: `1098069` (unchanged; already correct in the workflow).
- Success log and README identity corrected.
- Embedded `.github/workflows/main.yml` and standalone workflow YAML synchronized.
- Strict exact-source selection retained; no fallback to stale sources introduced.

## Local verification
- `node --check assets/js/app.js`: PASS.
- `node --check scripts/prepare-android-web.mjs`: PASS.
- `npm run build:web`: PASS; 13 required Android web assets verified.
- `npm test`: PASS; 38 tests, 0 failures.
- YAML parse: pending local parser availability / GitHub Actions execution.
- ZIP integrity: checked after packaging.

## Remaining external verification
A GitHub Actions run is required to confirm runner-side Android SDK, Gradle and APK packaging. This local hotfix does not claim a completed APK build.
