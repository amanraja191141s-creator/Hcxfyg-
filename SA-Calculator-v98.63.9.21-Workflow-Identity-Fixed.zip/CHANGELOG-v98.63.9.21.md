# Changelog — v98.63.9.21

## Video-matched Tools UI
- Rebuilt the Tools landing screen as grouped catalogue sections: Finance & Money, Math & General Utilities, Health, and Daily Utilities.
- Replaced wide horizontal cards with compact 3-column icon tiles matching the supplied reference recording.
- Removed the always-open subtitle/search/category-chip stack; search remains available from a compact search control.
- Added section-aware filtering so hidden search results also collapse empty category sections.
- Reset the visual hierarchy and spacing to prevent the first category heading/cards being clipped below the toolbar.

## Unit Converter category landing screen
- Added a 3-column category chooser with all 12 categories supported by the existing conversion engine.
- Selecting a category opens the existing From/To conversion workspace; the category dropdown remains as a hidden engine control.
- Added an in-screen All categories back action.
- Preserved the existing unit conversion factors, keypad, swap, result and conversion action.

## Verification
- Source JavaScript syntax and targeted regression tests are run for this release.
- Physical Android WebView screenshot and touch testing remain required before device-level certification.

## Android workflow identity hotfix
- Corrected the source selector to require the package version actually shipped in this archive: `1.98.69-v98.63.9.21`.
- Corrected APK `versionName` verification to the same value and retained the matching Android `versionCode` `1098069`.
- Corrected README release identity metadata so package version, workflow selector, APK verification and documented version code agree.
- Kept exact-source validation enabled; the workflow still refuses stale or unrelated project roots and archives.
